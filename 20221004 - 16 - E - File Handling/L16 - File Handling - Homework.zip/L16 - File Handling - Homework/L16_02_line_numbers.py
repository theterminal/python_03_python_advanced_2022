# 20221004 - Python - Python Advanced - File Handling
# 02 - Line Numbers


# _______________ version 1 _________________


from string import punctuation
# print(punctuation)


input_file_path = 'L16_02_files/text_02.txt'
output_file_path = 'L16_02_files/output_02.txt'

with open(input_file_path, 'r') as text_file:
    text = text_file.readlines()

with open(output_file_path, 'w') as output_file:
    for i in range(len(text)):
        row = text[i]

        letters = 0
        marks = 0

        for symbol in row:
            if symbol.isalpha():
                letters += 1
            elif symbol in punctuation:
                marks += 1

        output_file.write(f'Line {i + 1}: {"".join(row[:-1])} ({letters}) ({marks})\n')
