# 20221004 - Python - Python Advanced - File Handling
# 03 - File Manipulator


# _______________ version 1 _________________


from os import remove

while True:
    command = input().split('-')
    if command[0] == 'End':
        break

    file_name = command[1]

    if command[0] == 'Create':
        with open(file_name, 'w') as new_file:
            new_file.write('')

    elif command[0] == 'Add':
        content = command[2]

        try:
            with open(file_name, 'a') as the_file:
                the_file.write(f'{content}\n')
        except FileNotFoundError:
            print('An error occurred')

    elif command[0] == 'Replace':
        old_string = command[2]
        new_string = command[3]

        try:
            with open(file_name, 'r') as file:
                old_file = file.read()

            with open(file_name, 'w') as file:
                new_file_content = old_file.replace(old_string, new_string)
                file.write(new_file_content)
        except FileNotFoundError:
            print('An error occurred')

    elif command[0] == 'Delete':
        try:
            remove(file_name)

        except FileNotFoundError:
            print('An error occurred')

    else:
        print('Wrong Input')
        break
